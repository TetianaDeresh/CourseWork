package com.nulp.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nulp.command.*;
import com.nulp.repository.TariffRepository;
import com.nulp.response.ResponseEntity;
import com.nulp.tariff.Tariff;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LifecycleController {

    private List<Tariff> tariffList = new ArrayList<>();
    private final ApplicationContext context;
    private final TariffRepository tariffRepository;

    private final Map<String, Command> commands = new HashMap<>();
    private final Map<String, Object> commandParams = new HashMap<>();

    public LifecycleController(ApplicationContext context) {
        this.context = context;
        tariffRepository = this.context.getBean(TariffRepository.class);
    }

    {
        Command infoCommand = new HelpCommand(LifecycleController.this);
        Command exitCommand = new ExitCommand();
        Command loadFromFileCommand = new LoadFromFileCommand(LifecycleController.this);
        Command showTariffListCommand = new ShowTariffListCommand(LifecycleController.this);
        Command sortByTariffCostCommand = new SortByCostCommand(LifecycleController.this);
        Command getClientsAmountCommand = new GetClientsAmountCommand(LifecycleController.this);
        Command diapasonSearchCommand = new ClientsAmountDiapasonSearchCommand(LifecycleController.this);

        commands.put(infoCommand.getName(), infoCommand);
        commands.put(exitCommand.getName(), exitCommand);
        commands.put(loadFromFileCommand.getName(), loadFromFileCommand);
        commands.put(ShowTariffListCommand.NAME, showTariffListCommand);
        commands.put(SortByCostCommand.NAME, sortByTariffCostCommand);
        commands.put(GetClientsAmountCommand.NAME, getClientsAmountCommand);
        commands.put(ClientsAmountDiapasonSearchCommand.NAME, diapasonSearchCommand);
    }

    public List<Tariff> getTariffList() {
        return tariffList;
    }

    public ResponseEntity executeCommand(String command) {
        Command cmd = commands.get(command);
        if(cmd != null)
            return cmd.execute();
        else {
            ResponseEntity responseEntity = new ResponseEntity();
            responseEntity.addPair("Message", "No such command");
            return responseEntity;
        }
    }

    public void setTariffList(List<Tariff> tariffList) {
        this.tariffList = tariffList;
    }

    public TariffRepository getTariffRepository() {
        return tariffRepository;
    }

    public Map<String, Object> getCommandParams() {
        return commandParams;
    }
}
