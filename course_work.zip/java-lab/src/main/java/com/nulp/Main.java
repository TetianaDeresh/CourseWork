package com.nulp;

import com.mongodb.client.MongoClient;
import com.nulp.command.*;
import com.nulp.config.MongoConfig;
import com.nulp.controller.LifecycleController;
import com.nulp.repository.TariffRepository;
import com.nulp.response.ResponseEntity;
import com.nulp.tariff.ForeignCallsTariff;
import com.nulp.tariff.SpeakingTariff;
import com.nulp.tariff.Tariff;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;

import javax.swing.plaf.basic.BasicRadioButtonUI;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;

public class Main extends Application {

    private BorderPane root;

    private static final ApplicationContext context = new AnnotationConfigApplicationContext(MongoConfig.class);
//    private static final TariffRepository tariffRepository = context.getBean(TariffRepository.class);
    private final LifecycleController lifecycleController = new LifecycleController(context);

    @Override
    public void init() throws Exception {
        root = new BorderPane();
        root.setStyle("-fx-background-color: LIGHTBLUE");

        // Initializing control boxes
        VBox controlBoxHolder = new VBox();
        controlBoxHolder.setAlignment(Pos.CENTER);
        controlBoxHolder.setSpacing(10);
        controlBoxHolder.setPadding(new Insets(0, 20, 40, 20));

        HBox controlBox = new HBox();
        controlBox.setAlignment(Pos.CENTER);
        controlBox.setSpacing(25);

        VBox infoBox = new VBox();
        infoBox.setAlignment(Pos.CENTER);
        infoBox.setSpacing(20);
        infoBox.setPadding(new Insets(0, 20, 0, 20));

        // Initializing user control elements
        Text infoPanelText = new Text("������������ ������");

        TextArea textField = new TextArea();
        textField.setFocusTraversable(false);
        textField.setFont(Font.font(16));
        textField.setEditable(false);

        Button showTariffsBtn = new Button("������");
        showTariffsBtn.setOnAction(event -> {
            ResponseEntity response = lifecycleController.executeCommand(ShowTariffListCommand.NAME);
            textField.setText(response.toString());
        });

        Button clientsAmountBtn = new Button("�볺��� (�-���)");
        clientsAmountBtn.setOnAction(event -> {
            ResponseEntity response = lifecycleController.executeCommand(GetClientsAmountCommand.NAME);
            textField.setText(response.toString());
        });

        // Sort part
        Button sortCostCommand = new Button("��������� (����)");
        sortCostCommand.setOnAction(event -> {
            ResponseEntity response = lifecycleController.executeCommand(SortByCostCommand.NAME);
            textField.setText(response.toString());
        });

        // Search in diapason part
        HBox diapasonSearchBox = new HBox();
        diapasonSearchBox.setAlignment(Pos.CENTER);
        diapasonSearchBox.setSpacing(20);

        TextField leftBound = new TextField();
        leftBound.setPromptText("˳�� ����");
        leftBound.setMaxWidth(90);

        TextField rightBound = new TextField();
        rightBound.setPromptText("����� ����");
        rightBound.setMaxWidth(90);

        Button searchInDiapasonBtn = new Button("����� � ��������");
        searchInDiapasonBtn.setOnAction(event -> {
            long lb = Long.parseLong(leftBound.getText());
            long rb = Long.parseLong(rightBound.getText());

            lifecycleController.getCommandParams().put("lb", lb);
            lifecycleController.getCommandParams().put("rb", rb);

            ResponseEntity response = lifecycleController.executeCommand(ClientsAmountDiapasonSearchCommand.NAME);
            textField.setText(response.toString());
        });

        diapasonSearchBox.getChildren().addAll(
                searchInDiapasonBtn,
                leftBound,
                rightBound
        );

        controlBox.getChildren().addAll(
                showTariffsBtn,
                clientsAmountBtn,
                sortCostCommand,
                diapasonSearchBox
        );

        infoBox.getChildren().addAll(
                infoPanelText,
                textField
        );

        controlBoxHolder.getChildren().addAll(
                controlBox,
                diapasonSearchBox
        );

        root.setCenter(infoBox);
        root.setBottom(controlBoxHolder);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(root, 640, 480);
        primaryStage.setTitle("������� ������ ��������� ����� �.�. ��-202");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) throws IOException {
        launch(args);
    }
}
