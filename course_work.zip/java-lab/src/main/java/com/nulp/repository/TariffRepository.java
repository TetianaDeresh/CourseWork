package com.nulp.repository;

import com.nulp.tariff.Tariff;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TariffRepository extends MongoRepository<Tariff, String> {

    List<Tariff> findByClientsBetween(long lb, long rb);
}
