package com.nulp.command;

import com.nulp.controller.LifecycleController;
import com.nulp.response.ResponseEntity;
import com.nulp.tariff.Tariff;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ClientsAmountDiapasonSearchCommand extends Command {

    public static final String NAME = "dsrch";
    private final String desc = "Clients amount diapason search";

    private LifecycleController lc;

    public ClientsAmountDiapasonSearchCommand(LifecycleController lc) {
        this.lc = lc;
    }

    @Override
    public ResponseEntity execute() {
        ResponseEntity response = new ResponseEntity();

        long lb = (long)lc.getCommandParams().get("lb");
        long rb = (long)lc.getCommandParams().get("rb");

        List<Tariff> filteredTariffs = lc.getTariffRepository().findByClientsBetween(lb, rb);
        lc.setTariffList(filteredTariffs);
        response.addPair("Tariffs", filteredTariffs);
        return response;
    }

    public String getDesc() {
        return desc;
    }
}
