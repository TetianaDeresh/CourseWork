package com.nulp.command;

import com.nulp.controller.LifecycleController;
import com.nulp.response.ResponseEntity;
import com.nulp.tariff.Tariff;

import java.util.Optional;

public class GetClientsAmountCommand extends Command {

    public static final String NAME = "clients";
    private final String desc = "Get total clients amount";

    private LifecycleController lc;

    public GetClientsAmountCommand(LifecycleController lc) {
        this.lc = lc;
    }

    @Override
    public ResponseEntity execute() {
        ResponseEntity response = new ResponseEntity();
        Optional<Long> reduce = lc.getTariffRepository().findAll()
                .stream()
                .map(Tariff::getClients)
                .reduce(Long::sum);

        long clients = reduce.orElse(0L);
        response.addPair("Total clients amount", clients);
        return response;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
