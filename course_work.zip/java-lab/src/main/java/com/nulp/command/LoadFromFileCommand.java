package com.nulp.command;

import com.nulp.controller.LifecycleController;
import com.nulp.response.ResponseEntity;

import java.util.Scanner;

@Deprecated
public class LoadFromFileCommand extends Command {

    private final String name = "lff";
    private final String desc = "Load data from file";

    private LifecycleController lc;

    public LoadFromFileCommand(LifecycleController lc) {
        this.lc = lc;
    }

    @Override
    public ResponseEntity execute() {
        ResponseEntity response = new ResponseEntity();

        Scanner scanner = new Scanner(System.in);
        System.out.print("File name >> ");
        String fname = scanner.nextLine();

//        try {
//            List<Tariff> tariffList = lc.getObjectMapper().readValue(new File(fname), new TypeReference<List<Tariff>>(){});
//            lc.setTariffList(tariffList);
            response.addPair("status", "loaded");
//        } catch (IOException e) {
//            response.addPair("status", "failed");
//        }

        return response;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
