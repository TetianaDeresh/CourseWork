package com.nulp.command;

import com.nulp.controller.LifecycleController;
import com.nulp.response.ResponseEntity;
import com.nulp.tariff.Tariff;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SortByCostCommand extends Command {

    public static final String NAME = "sort";
    private final String desc = "Sort tariffs by cost";

    private LifecycleController lc;

    public SortByCostCommand(LifecycleController lc) {
        this.lc = lc;
    }

    @Override
    public ResponseEntity execute() {
        ResponseEntity responseEntity = new ResponseEntity();
        List<Tariff> tariffsCopy = new ArrayList<>(lc.getTariffList());
        tariffsCopy.sort(Comparator.comparing(Tariff::getCost));
        responseEntity.addPair("Sorted tariffs", tariffsCopy);
        return responseEntity;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
