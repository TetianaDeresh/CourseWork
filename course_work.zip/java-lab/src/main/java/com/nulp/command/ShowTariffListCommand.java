package com.nulp.command;

import com.nulp.controller.LifecycleController;
import com.nulp.response.ResponseEntity;
import com.nulp.tariff.Tariff;

import java.util.List;

public class ShowTariffListCommand extends Command {

    public static final String NAME = "lt";
    private final String desc = "List tariffs";

    private LifecycleController lc;

    public ShowTariffListCommand(LifecycleController lc) {
        this.lc = lc;
    }

    @Override
    public ResponseEntity execute() {
        ResponseEntity response = new ResponseEntity();
        List<Tariff> tariffs = lc.getTariffRepository().findAll();
        lc.setTariffList(tariffs);
        response.addPair("Tariffs", tariffs);
        return response;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
