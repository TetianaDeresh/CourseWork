package com.nulp.tariff;

public class SpeakingTariff extends Tariff {

    public static final String NAME = "Speaking Tariff";
    private int availableMinutes;
    private int availableMinutesOnOtherOperators;

    public int getAvailableMinutes() {
        return availableMinutes;
    }

    public void setAvailableMinutes(int availableMinutes) {
        this.availableMinutes = availableMinutes;
    }

    public int getAvailableMinutesOnOtherOperators() {
        return availableMinutesOnOtherOperators;
    }

    public void setAvailableMinutesOnOtherOperators(int availableMinutesOnOtherOperators) {
        this.availableMinutesOnOtherOperators = availableMinutesOnOtherOperators;
    }

    @Override
    public String toString() {
        return  "[" + NAME + "]" + "\n" +
                super.toString() + "\n" +
                "\tminutes: " + availableMinutes + "\n" +
                "\tminutes on other operators: " + availableMinutesOnOtherOperators;
    }
}
