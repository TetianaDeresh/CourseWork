package com.nulp.tariff;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        property = "type"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = InternetTariff.class, name = "internet_tariff"),
        @JsonSubTypes.Type(value = ForeignCallsTariff.class, name = "foreign_calls_tariff"),
        @JsonSubTypes.Type(value = SpeakingTariff.class, name = "speaking_tariff")
})
public abstract class Tariff {

    protected long id;
    protected long clients;
    protected BigDecimal cost;

    @Override
    public String toString() {
        return  "\tid: " + id + "\n" +
                "\tclients: " + clients + "\n" +
                "\tcost: " + cost;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getClients() {
        return clients;
    }

    public void setClients(long clients) {
        this.clients = clients;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }
}
