package com.nulp.tariff;

import java.util.List;

public class ForeignCallsTariff extends Tariff {

    public static final String NAME = "Foreign Calls Tariff";
    private List<String> availableCountries;
    private int availableMinutes;

    public List<String> getAvailableCountries() {
        return availableCountries;
    }

    public void setAvailableCountries(List<String> availableCountries) {
        this.availableCountries = availableCountries;
    }

    public int getAvailableMinutes() {
        return availableMinutes;
    }

    public void setAvailableMinutes(int availableMinutes) {
        this.availableMinutes = availableMinutes;
    }

    @Override
    public String toString() {
        return "[" + NAME + "]" + "\n" +
                super.toString() + "\n" +
                "\tcountries: " + availableCountries + "\n" +
                "\tminutes: " + availableMinutes;
    }
}
