package com.nulp.tariff;

import java.util.List;

public class InternetTariff extends Tariff {

    public static final String NAME = "Internet Tariff";
    private int internetMegabytes;
    private List<String> unlimitedAccessServices;

    public int getInternetMegabytes() {
        return internetMegabytes;
    }

    public void setInternetMegabytes(int internetMegabytes) {
        this.internetMegabytes = internetMegabytes;
    }

    public List<String> getUnlimitedAccessServices() {
        return unlimitedAccessServices;
    }

    public void setUnlimitedAccessServices(List<String> unlimitedAccessServices) {
        this.unlimitedAccessServices = unlimitedAccessServices;
    }

    @Override
    public String toString() {
        return "[" + NAME + "]" + "\n" +
                super.toString() + "\n" +
                "\tmegabytes: " + internetMegabytes + "\n" +
                "\tunlimited access to: " + unlimitedAccessServices;
    }
}
